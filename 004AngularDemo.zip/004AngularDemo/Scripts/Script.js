﻿//Create Module
var myapp = angular.module("myModule", []);

////Register module with controller
myapp.controller("myController", function ($scope,$http,$location,$anchorScroll) {
    $scope.message = "Angular Demo";
    var user = 
        {
            firstname:"mayur",
            lastname: "mewada"
        }


    $scope.user = user;
    var nation = [
                 {
                     name: "India",
                     states: [
                           { name: "Gujrat" },
                           { name: "Rajsthan" },
                           { name: "Uttarpradesh" }
                     ]
                 },
                 {
                     name: "Pakistan",
                     states: [
                       { name: "Gujrat" },
                       { name: "Rajsthan" },
                       { name: "Uttarpradesh" }
                     ]
                 },
                 {
                     name: "USA",
                     states: [
                   { name: "Gujrat" },
                   { name: "Rajsthan" },
                   { name: "Uttarpradesh" }
                     ]
                 }
                ];


    $scope.nation = nation;
            $scope.country =
            {
            name: "India",
            flag:"/images/india.png"
            }

       $scope.Greeting = "";

       $scope.technology =
               [
                { name: "HTML", Like:0, Dislike:0 },
                { name: "CSS", Like:0, Dislike:0 },
                { name: "Javascript", Like:0, Dislike: 0},
                { name: "Angular", Like: 0, Dislike: 0 },
               { name: "Nodejs", Like: 0, Dislike:0 },
                { name: "Reactjs", Like: 0, Dislike: 0 },
               { name: "Jquery", Like: 0, Dislike: 0 }
               ];
       $scope.increamentlike = function (technologies) {
           technologies.Like++;
       }

       $scope.decreamentlike = function (technologies) {
           technologies.Dislike++;
       }

       $scope.rowlimit = 7;
       $scope.sortColumn = "Name";
       $scope.reverseSort = false;


       $scope.sortData = function (column) {
           $scope.reverseSort = ($scope.sortColumn == column) ? !$scope.reverseSort : false
           $scope.sortColumn = column;
       }

       $scope.getSortClass=function(column){
           if($scope.sort)
           {
               return $scope.reverseSort  ? 'arrow-down' : 'arrow-up'
           }
           return '';
       }





    //webserver using http 
       $http.get('WebService.asmx/GetEmployeeData').then(function (response) {
           $scope.employees = response.data;
       });
    //anchorscroll
       $scope.scrollTo = function (scrollLocation) {
           $location.hash();
           $anchorscroll();
           $anchorscroll().yOffset=20;
       }
});



