﻿myapp.filter("tech", function () {
    return function (tech) {
        switch (tech) {
            case 1:
                return "name";
            case 2:
                return "Like";
            case 3:
                return "Dislike";
        }
    }

})