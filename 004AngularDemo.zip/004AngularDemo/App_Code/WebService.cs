﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml;
using System.Data;
using System.Data.SqlClient;
using System.Web.Script.Serialization;
using System.Configuration;
using CRM_AppsTech.App_Code;


/// <summary>
/// Summary description for WebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.  
[System.Web.Script.Services.ScriptService]
public class WebService : System.Web.Services.WebService
{
    //Kingston Customer Data
    [WebMethod(Description = "Webservice for Kingston")]
    public void GetKingstonCustomerData(String APIKey)
    {
        Class1 obj = new Class1();
        DataSet ds = new DataSet();
        try
        {
            ds = obj.calldata("select * from Tbl_Authentication where SecretKey='" + APIKey + "'");
            if (ds.Tables[0].Rows.Count != 0)
            {
                List<Customer> custlist = new List<Customer>();
                string cs = ConfigurationManager.ConnectionStrings["Kingston"].ConnectionString;

                using (SqlConnection connection = new SqlConnection(cs))
                {
                    string query = "select * from Tbl_Kingston_Work";
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    {
                        while (reader.Read())
                        {
                            Customer cus = new Customer();
                            cus.id = Convert.ToInt32(reader["Id"]);
                            cus.OldCaseNumber = reader["OldCaseNumber"].ToString();
                            cus.Name = reader["Name"].ToString();
                            cus.Email = reader["Email"].ToString();
                            cus.MobileNo = reader["MobileNo"].ToString();
                            cus.City = reader["City"].ToString();
                            cus.Call_Receive_Date = reader["Call_Receive_Date"].ToString();
                            cus.Category = reader["Category"].ToString();
                            cus.ProductIssue = reader["ProductIssue"].ToString();
                            cus.Solution = reader["Solution"].ToString();
                            cus.Model = reader["Model"].ToString();
                            cus.Capacity = reader["Capacity"].ToString();
                            cus.Callid = reader["Callid"].ToString();
                            cus.DepositeDate = reader["DepositeDate"].ToString();
                            cus.ActionTaken = reader["ActionTaken"].ToString();
                            cus.Status = reader["Status"].ToString();
                            cus.WMS_Status = reader["WMS_Status"].ToString();
                            cus.Remarks = reader["Remarks"].ToString();
                            cus.NewCaseNumber = reader["NewCaseNumber"].ToString();
                            custlist.Add(cus);
                        }
                    }
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    Context.Response.Write(js.Serialize(custlist));
                }
            }
        }
        catch (Exception ex)
        {
               
        }

   
    }
}
