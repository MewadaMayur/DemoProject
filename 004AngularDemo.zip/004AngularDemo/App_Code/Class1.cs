﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;    
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace CRM_AppsTech.App_Code
{
        public class Class1
        {
      public  SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Kingston"].ConnectionString);
            internal void savedata(string v1, string v2)
        {
            throw new NotImplementedException();
        }
            public Class1()
            {

            }
            public void savedata(string qry)
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(qry, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            public DataSet calldata(string qry)
            {
                SqlDataAdapter sd = new SqlDataAdapter(qry, con);
                DataSet ds = new DataSet();
                sd.Fill(ds);
                return ds;
            }
    }

    public class Employee
    {
        //employe data
        public int id { get; set; }
        public string name { get; set; }
        public string designation { get; set; }
    }

    public class Customer
    {
        //employe data
        public int id { get; set; }
        public string OldCaseNumber { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string MobileNo { get; set; }
        public string City { get; set; }
        public string Call_Receive_Date { get; set; }
        public string Category { get; set; }
        public string ProductIssue { get; set; }
        public string Solution { get; set; }
        public string Model { get; set; }
        public string Capacity { get; set; }
        public string Callid { get; set; }
        public string DepositeDate { get; set; }
        public string ActionTaken { get; set; }
        public string Status { get; set; }
        public string WMS_Status { get; set; }
        public string Remarks { get; set; }
        public string NewCaseNumber { get; set; }
        public string Emp_code { get; set; }
      }
}